#input boolean open

if(open){
	return ["resultCode":"success"]
} 
else {
	return ["resultCode":"error"]
}