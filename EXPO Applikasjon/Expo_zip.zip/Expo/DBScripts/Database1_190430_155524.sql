-- Stand [ent2]
alter table `stand`  add column  `poster`  varchar(255);


