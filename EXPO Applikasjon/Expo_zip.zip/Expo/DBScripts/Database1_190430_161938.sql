-- AktivExpo [ent7]
create table `aktivexpo` (
   `aktivexpo`  varchar(255)  not null,
  primary key (`aktivexpo`)
);


