-- Vote [ent5]
alter table `vote`  add column  `votevalue_2`  integer;


