-- Category [ent6]
drop table `category`;
